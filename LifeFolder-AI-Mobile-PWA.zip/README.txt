LifeFolder AI — Mobile PWA test package

Install on iPhone:
1) Host all files on an HTTPS website (for example GitHub Pages).
2) Open the HTTPS site in Safari.
3) Share > Add to Home Screen > Add.

This is an installable web app prototype, not an App Store native app.
Files are stored locally in IndexedDB on this device/browser. No cloud sync,
real login, encryption, OCR or AI is connected yet. Do not test with sensitive
original documents. Keep all files in the same folder when hosting.
